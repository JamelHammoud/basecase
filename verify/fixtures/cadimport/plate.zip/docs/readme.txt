Mounting plate, 40 x 30 x 5 mm.
